package firstPackage;

public class B {
    public void tip() {
        System.out.println("class B");
    }
}