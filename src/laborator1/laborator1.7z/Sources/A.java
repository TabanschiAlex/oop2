package firstPackage;

public class A {
    public void tip() {
        System.out.println("class A");
    }
}