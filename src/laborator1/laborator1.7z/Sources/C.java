package firstPackage.subprogram;

public class C {
    public void tip() {
        System.out.println("Class from sub package");
    }
}