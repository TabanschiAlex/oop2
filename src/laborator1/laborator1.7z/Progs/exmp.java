import firstPackage.*;

public class exmp {
    public static void main(String args[]) {
        A x = new A();
        B y = new B();

        System.out.println("Uses first package!");
        x.tip();
        y.tip();
    }
}