import firstPackage.subprogram.*;

public class Inv {
    public static void main(String args[]) {
        C x = new C();

        x.tip();
    }
}