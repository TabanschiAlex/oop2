import Laborator.*;
import java.util.Scanner;

public class Four {
    public static void main(String args[]) {
        String option = "";
        Scanner read = new Scanner(System.in);
        MinValue min = new MinValue();
        DeleteMiddleNum del = new DeleteMiddleNum();
        avgNumbers avg = new avgNumbers();
        CirculateNum rotate = new CirculateNum();
        Subunit subunit = new Subunit();

        do {
            System.out.print("Select option (avg, delete, min, rotate, subunitly): ");
            option = read.next();
            switch (option) {
                case "avg":
                    System.out.println("Average number: " + avg.calculate());
                    break;
                case "delete":
                    System.out.println("After delete middle number: " + del.deleteMiddleNum());
                    break;
                case "min":
                    System.out.println("Minimal value is: " + min.getMinValue());
                    break;
                case "rotate":
                    rotate.circulate();
                    break;
                case "subunitly":
                    subunit.show();
                    break;

            }
        } while (option == "exit");

    }
}


 /*public void test() {
        ArrayList<Integer> example = new ArrayList<>();

        example.add(5);
        example.add(6);

        System.out.println(example);
    }*/

    /*public final static int[] addElem(int arr[], int n, int elem) {
        int[] newArr = new int[n + 1] ;

        for (int i = 0; i < arr.length; i++) {
            newArr[i] = arr[i];
        }

        newArr[n] = elem;
        return newArr;
    }*/